import { MODULE_ID } from "./main.js";

export function initConfig() { }